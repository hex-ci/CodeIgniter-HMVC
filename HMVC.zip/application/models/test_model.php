<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * home
 *
 * @package default
 * @author
 **/
class Test_model extends CI_Model {

	/**
	 * undocumented function
	 *
	 * @return void
	 * @author
	 **/
	function __construct()
	{
		parent::__construct();
	}

	function abc()
	{
		echo '<p>8888888888888888888888888</p>';
	}

}
